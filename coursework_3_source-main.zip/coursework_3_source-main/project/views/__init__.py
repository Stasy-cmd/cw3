from .genres import genres_ns

__all__ = [
    "genres_ns",
]
