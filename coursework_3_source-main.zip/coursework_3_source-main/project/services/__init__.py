from .genres_service import GenresService

__all__ = ["GenresService"]
