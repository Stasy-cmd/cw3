from .genre import Genre

__all__ = [
    "Genre",
]
