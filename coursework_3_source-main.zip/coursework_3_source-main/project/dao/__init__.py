from .genre import GenreDAO

__all__ = [
    "GenreDAO",
]
